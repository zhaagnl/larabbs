<?php

declare(strict_types=1);

namespace Intervention\Image\Encoders;

use Error;
use Intervention\Image\Exceptions\InvalidArgumentException;
use Intervention\Image\Exceptions\NotSupportedException;
use Intervention\Image\FileExtension;
use Intervention\Image\Interfaces\EncodedImageInterface;
use Intervention\Image\Interfaces\EncoderInterface;
use Intervention\Image\Interfaces\ImageInterface;

class FileExtensionEncoder extends AutoEncoder
{
    /**
     * Encoder options.
     *
     * @var array<int|string, mixed>
     */
    protected array $options = [];

    /**
     * Create new encoder instance to encode to format of given file extension.
     *
     * @param null|string|FileExtension $extension Target file extension for example "png"
     * @throws InvalidArgumentException
     * @throws NotSupportedException
     */
    public function __construct(public null|string|FileExtension $extension = null, mixed ...$options)
    {
        if ($extension === '') {
            throw new InvalidArgumentException('Unable to find file extension from empty string');
        }

        $mediaType = null;

        if (is_string($extension)) {
            try {
                $mediaType = FileExtension::from(strtolower($extension))->mediaType();
            } catch (Error) {
                throw new NotSupportedException(
                    'Unable to find encoder for unknown file extension "' . $extension . '"',
                );
            }
        }

        if ($extension instanceof FileExtension) {
            $mediaType = $extension->mediaType();
        }

        parent::__construct($mediaType, ...$options);
    }

    /**
     * {@inheritdoc}
     *
     * @see EncoderInterface::encode()
     *
     * @throws NotSupportedException
     * @throws InvalidArgumentException
     */
    public function encode(ImageInterface $image): EncodedImageInterface
    {
        $extension = is_null($this->extension) ? $image->origin()->fileExtension() : $this->extension;

        if ($extension === null) {
            throw new NotSupportedException('Unable to find encoder by unknown origin file extension');
        }

        return $image->encode(
            $this->encoderByFileExtension(
                $extension,
            ),
        );
    }

    /**
     * Create matching encoder for given file extension
     *
     * @throws InvalidArgumentException
     * @throws NotSupportedException
     */
    protected function encoderByFileExtension(string|FileExtension $extension): EncoderInterface
    {
        if ($extension === '') {
            throw new InvalidArgumentException('Argument $extension must not be an empty string');
        }

        try {
            $extension = is_string($extension) ? FileExtension::from(strtolower($extension)) : $extension;
        } catch (Error) {
            throw new NotSupportedException(
                'Unable to find encoder for unknown image file extension "' . $extension . '"',
            );
        }

        return $extension->format()->encoder(...$this->options);
    }
}
